﻿'use strict';

//module.exports = function() {
console.log('hi pcht');

$(document).ready(function() {

	var _save = true;
	var _event, _postOfficeArr;

	$(".flatpickr").flatpickr({
		enableTime: true,
	});

	ymaps.ready(init);
	var myMap;

	function init() {
		myMap = new ymaps.Map("mapy", {
			center: [50.59, 36.58],
			zoom: 10
		}, {
             buttonMaxWidth: 150
        });

		$.ajax({
			type: 'GET',
			url: "./postals.json",
			dataType: "json",
			success: function(data) {

				_postOfficeArr = data;

				var tpl = require('./view/postOfficeDetail.jade');
				var myBalloonContentBodyLayout = ymaps.templateLayoutFactory.createClass(
					'<p>$[properties.data.postalCode]</p><p>$[properties.data.addressSource]</p><p>$[properties.data.typeCode]</p><br /><button id="show-po-detail-btn">Подробно</button>', {
						build: function() {
							myBalloonContentBodyLayout.superclass.build.call(this);
							$('#show-po-detail-btn').on('click', {
								"po": this._data.properties._data
							}, this.onShowPODetailClick);
						},
						clear: function() {
							$('#show-po-detail-btn').off('click', this.onShowPODetailClick);
							myBalloonContentBodyLayout.superclass.clear.call(this);
						},
						onShowPODetailClick: function(e) {
							$('.pod-place').html(tpl({
								"data": e.data.po.data
							}));
						}
					});

				data.forEach(function(otd) {
					//console.log(otd.latitude);

					var pmark = new ymaps.Placemark([otd.latitude, otd.longitude],
						/*{
						hintContent: otd.postalCode,
						balloonContent: "<p>"+otd.postalCode+"</p><p>"
						+otd.addressSource+"</p><p>"
						+otd.typeCode+
						"</p><a href='#' class='btn btn-primary' id='post-detail' data-postalcode='"+otd.postalCode+"'>Подробнее</a>"
					}*/
						{
							data: otd, iconContent: otd.postalCode,iconCaption:otd.postalCode
						}, {
							balloonContentLayout: myBalloonContentBodyLayout, preset: 'islands#blackStretchyIcon' 
						}
					);
					myMap.geoObjects.add(pmark);
				});

				/*$('.post-detail').click(function(e){
					console.log('click clack');
					var pcode=$(e.currentTarget).attr('data-postalcode');
					_postOfficeArr.forEach(function(otd){
						if(otd.postalCode===pcode){
							var tpl=require('./view/postOfficeDetail.jade');
							$('.pod-place').html(tpl({"data":otd}));
						}
					});
				});*/

			},
			//error: loadError
		});

	}


	$.ajax({
		type: 'GET',
		url: "/users",
		dataType: "json",
		success: function(data) {
			calendarInit(data);
		},
		//error: loadError
	});


	function calendarInit(_events) {

		var _newEventModal = require('./module/newEventModal.js');
		var _newModal = new _newEventModal();
		var _editEventModal = require('./module/editEventModal.js');
		var _editModal = new _editEventModal();

		$('#calendar').fullCalendar({
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,agendaWeek,agendaDay'
			},
			selectable: true,
			selectHelper: true,
			editable: true,

			select: function(start, end, jsEvent, view) {

				_newModal.init(start, end);

			},
			eventClick: function(event, jsEvent, view) {

				_editModal.init(event);

			},
			eventAfterRender: function(event, element, view) {

				console.log('e a r');

			},
			eventAfterAllRender: function(view) {

				console.log('e a a r');
			},
			defaultView: 'month',
			editable: true,
			events: _events
		});

		var listmod = require('./module/listmod.js');
		var _listmod=new listmod();
		_listmod.init();
		
	}



});

//}